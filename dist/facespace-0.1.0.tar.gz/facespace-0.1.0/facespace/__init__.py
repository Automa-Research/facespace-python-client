# facespace/__init__.py
from .facespace_client import LogsAPI, FaceSpaceError